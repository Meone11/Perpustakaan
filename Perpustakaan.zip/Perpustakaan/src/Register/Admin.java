/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Register;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import pendataanmahasiswa.Mahasiswa;
import pendataanmahasiswa.MyConncetion;

/**
 *
 * @author meone
 */
public class Admin {
    
    public void FillToTableDashboard(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Kondisi_Buku`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[3];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(5);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToTableMasterData(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Kondisi_Buku`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[3];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(5);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToTableBukuMasuk(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Tanggal`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[3];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void FillToTableBukuRusak(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        String kondisi;
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Kondisi_Buku`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                kondisi = rs.getString(5);
                if (kondisi.equals("Rusak")){
                    row = new Object[3];
                    row[0] = ++i;
                    row[1] = rs.getString(1);
                    row[2] = rs.getString(2);
                
                    model.addRow(row);
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToTableRiwayatInventory(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Tanggal`, `Petugas`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[4];
                row[0] = rs.getString(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToTableBukuDiPinjam(JTable table){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `BookHistory`");
//            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            while (rs.next()){
                if (rs.getBoolean(9)){
                    row = new Object[4];
                    row[0] = rs.getString(2);
                    row[1] = rs.getString(3);
                    row[2] = rs.getString(7);
                    row[3] = rs.getBoolean(9);
                    
                    model.addRow(row);
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void InsertUpdateDelete(char Operation, String Kode,int Status, String tanggal){
        PreparedStatement ps;
//        String query = "INSERT INTO `DataMahasiswa`(`Nama`, `Prodi`, `Email`, `Password`, `Jenis Kelamin`, `Tanggal Lahir`, `NPM`, `No Telepon`) VALUES (?,?,?,?,?,?,?,?)";
        if (Operation == 'u'){ // u For Update or Edit Data
            try {
                ps = (PreparedStatement) MyConnection.getConnection().prepareStatement("UPDATE `BookHistory` SET `Status`= ? WHERE Kode_Buku = ? AND Tanggal = ?");
                ps.setString(2, Kode);
                ps.setInt(1, Status);
                ps.setString(3, tanggal);
                
                if (ps.executeUpdate() > 0){
//                    JOptionPane.showMessageDialog(null,"Data Berhasil Di Update");
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void FillToTableBukuDikembalikan(JTable table, String cari){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `BookHistory` WHERE CONCAT(`Kode_Buku`, `Judul_Buku`, `Tanggal`) LIKE ?");
            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[3];
                row[0] = rs.getString(2);
                row[1] = rs.getString(3);
                row[2] = rs.getString(7);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void FillToTableRiwayatPeminjaman(JTable table){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `BookHistory`");
//            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            while (rs.next()){
                
                row = new Object[8];
                row[0] = ++i;
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getString(7);
                row[7] = rs.getBoolean(9);
                    
                model.addRow(row);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void InsertBook(char Operation, String Kode, String Judul, String Tanggal, String Petugas, String Kondisi){
        PreparedStatement ps;
        String query = "INSERT INTO `InventoryBook`(`Kode_Buku`, `Judul_Buku`, `Tanggal`, `Petugas`, `Kondisi_Buku`) VALUES (?,?,?,?,?)";
        if (Operation == 'i'){
            try {
                ps = (PreparedStatement) MyConnection.getConnection().prepareStatement(query);
                ps.setString(1, Kode);
                ps.setString(2, Judul);
                ps.setString(3, Tanggal);
                ps.setString(4, Petugas);
                ps.setString(5, Kondisi);
                
                if (ps.executeUpdate() > 0){
                    JOptionPane.showMessageDialog(null,"Data Berhasil Di input!");
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
}
