/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Register;


import com.mysql.jdbc.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author meone
 */
public class Register {
    String username, password, Nama, tanggalLahir, jurusan, kelas, profile;
    byte[] photo;

    public Register() {
    }

    public Register(String username, String password, String Nama, String tanggalLahir, String jurusan, String kelas, String profile, byte[] photo) {
        this.username = username;
        this.password = password;
        this.Nama = Nama;
        this.tanggalLahir = tanggalLahir;
        this.jurusan = jurusan;
        this.kelas = kelas;
        this.profile = profile;
        this.photo = photo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getJurusan() {
        return jurusan;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getKelas() {
        return kelas;
    }

    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }
    
    //add new user
    public void addUser(String username, String password, String Nama, String tanggalLahir, String jurusan, String kelas, String profile, byte[] photo){
        String query = "INSERT INTO `Login`(`user`, `pass`, `nama`, `tanggalLahir`, `jurusan`, `kelas`, `foto`, `profile`) VALUES (?,?,?,?,?,?,?,?)";
        
        try {
            PreparedStatement ps = (PreparedStatement) MyConnection.getConnection().prepareStatement(query);
            
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, Nama);
            ps.setString(4, tanggalLahir);
            ps.setString(5, jurusan);
            ps.setString(6, kelas);
            ps.setBytes(7, photo);
            ps.setString(8, profile);
            
            if (ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Register Successfull!", "Success", 1);
            }else{
                JOptionPane.showMessageDialog(null, "Register Failed!", "Failed", 2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
}
