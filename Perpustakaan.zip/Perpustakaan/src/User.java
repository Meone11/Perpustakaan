
import Register.MyConnection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import pendataanmahasiswa.Mahasiswa;
import pendataanmahasiswa.MyConncetion;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author meone
 */
public class User {
    
    public void FillToTableDashboard(JTable table){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        boolean cek;
        
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `InventoryBook`");
//            ps.setString(1,"%"+cari+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[4];
                row[0] = ++i;
                row[1] = rs.getString(1);
                row[2] = rs.getString(2);
                row[3] = null;
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToPeminjamanForm(JTextField kode, JTextField judul, JTextField kondisi, String Kode){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        boolean cek;
        
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT `Kode_Buku`, `Judul_Buku`, `Kondisi_Buku` FROM `InventoryBook` WHERE Kode_Buku = ?");
            ps.setString(1,Kode);
            
            ResultSet rs = ps.executeQuery();
//            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                
                kode.setText(rs.getString(1));
                judul.setText(rs.getString(2));
                kondisi.setText(rs.getString(3));
                
//                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void InsertUpdateDelete(char Operation, String Kode, String Judul, String Nama, String Kelas, String Jurusan, String Tanggal, String Status){
        PreparedStatement ps;
        String query = "INSERT INTO `BookHistory`(`Kode_Buku`, `Judul_Buku`, `Nama_User`, `Kelas`, `Jurusan`, `Tanggal`, `Kondisi`, `Status`) VALUES (?,?,?,?,?,?,?,?)";
        if (Operation == 'i'){
            try {
                ps = (PreparedStatement) MyConnection.getConnection().prepareStatement(query);
                ps.setString(1, Kode);
                ps.setString(2, Judul);
                ps.setString(3, Nama);
                ps.setString(4, Kelas);
                ps.setString(5, Jurusan);
                ps.setString(6, Tanggal);
                ps.setString(7, Status);
                ps.setInt(8, 1);
                
                if (ps.executeUpdate() > 0){
                    JOptionPane.showMessageDialog(null,"Data Berhasil Di input!");
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void FillToTableBukuDipinjam(JTable table, String nama){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        boolean cek;
        
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `BookHistory` WHERE Nama_User = ?");
            ps.setString(1, nama);
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[5];
                row[0] = ++i;
                row[1] = rs.getString(1);
                row[2] = rs.getString(2);
                row[3] = rs.getString(3);
                row[4] = rs.getString(7);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void FillToTableRiwayat(JTable table){
        Connection c = MyConnection.getConnection();
        PreparedStatement ps;
        
        boolean cek;
        
        int i = 0;
        
        try {
            ps = (PreparedStatement) c.prepareStatement("SELECT * FROM `BookHistory`");
//            ps.setString(1, nama);
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            
            while (rs.next()){
                row = new Object[7];
                row[0] = ++i;
                row[1] = rs.getString(1);
                row[2] = rs.getString(2);
                row[3] = rs.getString(3);
                row[4] = rs.getString(4);
                row[5] = rs.getString(7);
                row[6] = rs.getString(8);
                
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Mahasiswa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }    
    
}
